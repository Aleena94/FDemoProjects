package com.example.practicetest.model

class ToDoModel : ArrayList<ToDoModelItem>()
package com.example.practicetest.view

import android.content.Context
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.practicetest.R
import com.example.practicetest.adapter.ToDoAdapter
import com.example.practicetest.databinding.ActivityMainBinding
import com.example.practicetest.interfaces.ItemClickListener
import com.example.practicetest.model.ToDoModelItem
import com.example.practicetest.services.isOnline
import com.example.practicetest.viewmodel.ToDoViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.koin.android.ext.android.inject
import java.util.*


class MainActivity : AppCompatActivity(), ItemClickListener {
    lateinit var binding: ActivityMainBinding
    lateinit var context: Context
    private lateinit var layoutManager: LinearLayoutManager
    private lateinit var adapter: ToDoAdapter
    private val toDoViewModel: ToDoViewModel by inject()
    private var toDoItem: List<ToDoModelItem> = ArrayList<ToDoModelItem>()
    val PREFS_NAME = "MyPrefsFile"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        context = this@MainActivity

        layoutManager = LinearLayoutManager(this)
        adapter = ToDoAdapter(toDoItem, context as MainActivity)

        var prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        val editor: SharedPreferences.Editor = prefs.edit()
        val isFirstRun = prefs.getBoolean("firstRun", true)
        if (isFirstRun) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                if (isOnline(context)) {
                    loadToDo()
                }
            }
            editor.putBoolean("firstRun", false)
            editor.apply()
            editor.commit()
        } else {

            toDoViewModel.getToDoDetails()!!.observe(this, {
                if (it != null) {
                    toDoItem = it

                    binding.todoRecycler.layoutManager =
                        LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
                    binding.todoRecycler.adapter = adapter
                    adapter.setToDoList(toDoItem)

                }
            })
        }


    }

    @RequiresApi(Build.VERSION_CODES.M)
    private fun loadToDo() {
        toDoViewModel.getToDo()!!.observe(this, { toDoList ->

            if (toDoList != null) {
                toDoItem = toDoList
                lifecycleScope.launch {
                    toDoViewModel.insertToDoData(toDoItem)
                }
                binding.todoRecycler.layoutManager =
                    LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false)
                binding.todoRecycler.adapter = adapter
                adapter.setToDoList(toDoItem)
            }

        })


    }

    override fun onItemClick(favourite: Boolean, id: Int, position: Int) {
        CoroutineScope(Dispatchers.IO).launch {
            toDoViewModel.updateFavourites(favourite, id)
        }
        adapter.notifyItemChanged(position)
    }
}